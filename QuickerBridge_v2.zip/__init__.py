bl_info = {
    "name": "Quicker_Bridge",
    "author": "Rainsky & AI",
    "version": (2, 0),
    "blender": (5, 0, 0),
    "location": "快捷键 / 插件设置面板",
    "description": "提供 HTTP 接口与剪贴板快捷键执行 Python 代码",
    "warning": "",
    "doc_url": "",
    "category": "System",
}

import bpy
import bmesh
import time
import os
import threading
import queue
import json
import traceback # 用于输出深层错误但不崩溃
# 【核心修复 1】：引入多线程 HTTP 服务器，解决单线程并发拥堵和死锁问题
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

# ==========================================
# 1. 全局状态与资源管理
# ==========================================
api_queue = queue.Queue()
global_mouse = {"x": 0, "y": 0}

http_daemon = None
http_thread = None
addon_running = False

addon_keymaps = []

# ==========================================
# 2. 插件偏好设置 (UI 面板)
# ==========================================
class QuickerAddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    server_address: bpy.props.StringProperty(
        name="服务器地址:端口",
        description="设置 HTTP 监听的 IP 和端口，修改后需点击重启生效",
        default="127.0.0.1:8765"
    )

    def draw(self, context):
        layout = self.layout
        
        box = layout.box()
        box.label(text="🌐 HTTP 服务器设置", icon='WORLD')
        row = box.row()
        row.prop(self, "server_address")
        
        status_icon = 'PLAY' if http_daemon else 'PAUSE'
        status_text = "重启服务以应用新端口" if http_daemon else "启动服务"
        row.operator("wm.restart_quicker_server", text=status_text, icon=status_icon)
        
        box = layout.box()
        box.label(text="⌨️ 剪贴板快捷键设置", icon='KEYINGSET')
        
        wm = context.window_manager
        kc = wm.keyconfigs.user
        if kc:
            km = kc.keymaps.get('Window')
            if km:
                kmi = km.keymap_items.get('wm.run_clipboard_code')
                if kmi:
                    box.context_pointer_set("keymap", km)
                    try:
                        import rna_keymap_ui
                        rna_keymap_ui.draw_kmi([], kc, km, kmi, box, 0)
                    except Exception:
                        row = box.row()
                        row.prop(kmi, "type", text="", full_event=True)
                        row.prop(kmi, "value", text="")
                        row = box.row()
                        row.prop(kmi, "ctrl", text="Ctrl")
                        row.prop(kmi, "shift", text="Shift")
                        row.prop(kmi, "alt", text="Alt")

# ==========================================
# 3. 核心功能：运行剪贴板代码
# ==========================================
class WM_OT_RunClipboardCode(bpy.types.Operator):
    bl_idname = "wm.run_clipboard_code"
    bl_label = "运行剪贴板 Python 代码"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            code = context.window_manager.clipboard
            if not code or "bpy" not in code:
                self.report({'WARNING'}, "剪贴板中未检测到有效的 Blender Python 代码")
                return {'CANCELLED'}
            
            namespace = globals().copy()
            namespace.update(locals())
            exec(code, namespace)
            
            self.report({'INFO'}, "✅ 剪贴板代码已成功执行")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"❌ 代码执行错误: {str(e)}")
            return {'CANCELLED'}

# ==========================================
# 4. HTTP 服务器与坐标间谍相关类
# ==========================================
class WM_OT_RestartQuickerServer(bpy.types.Operator):
    bl_idname = "wm.restart_quicker_server"
    bl_label = "重启 Quicker 监听服务"
    
    def execute(self, context):
        stop_server()
        start_server()
        self.report({'INFO'}, "HTTP 服务已重启")
        return {'FINISHED'}

class MouseContextSpy(bpy.types.Operator):
    bl_idname = "wm.mouse_context_spy"
    bl_label = "Mouse Context Spy"
    
    def modal(self, context, event):
        if not addon_running:
            return {'FINISHED'}
            
        if event.type == 'MOUSEMOVE':
            global_mouse["x"] = event.mouse_x
            global_mouse["y"] = event.mouse_y
        return {'PASS_THROUGH'}
        
    def invoke(self, context, event):
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

class QuickerAPI(BaseHTTPRequestHandler):
    def _send_response(self, code, body):
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Connection', 'close')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        evt, res = threading.Event(), {}
        api_queue.put({"type": "GET", "evt": evt, "res": res})
        # 【优化】：稍微延长GET的超时，避免Blender在保存大文件时的极短暂卡顿导致报错
        if evt.wait(timeout=1.5):
            body = json.dumps({"status": res.get("status", "UNKNOWN_NONE")}).encode('utf-8')
            self._send_response(200, body)
        else:
            self._send_response(500, json.dumps({"error": "BLENDER TIMEOUT"}).encode('utf-8'))

    def do_POST(self):
        try:
            length = int(self.headers.get('Content-Length', 0))
            code = self.rfile.read(length).decode('utf-8')
            if not code.strip(): raise ValueError("代码为空")
            
            evt, res = threading.Event(), {}
            api_queue.put({"type": "POST", "payload": code, "evt": evt, "res": res})
            
            # 【优化】：POST超时时间提升到 5.0 秒，允许较重型的操作(如复杂节点创建)执行完毕
            if evt.wait(timeout=5.0): 
                self._send_response(200 if res.get("success") else 500, json.dumps(res).encode('utf-8'))
            else:
                self._send_response(500, json.dumps({"error": "EXECUTION TIMEOUT"}).encode('utf-8'))
        except Exception as e:
            self._send_response(400, json.dumps({"error": str(e)}).encode('utf-8'))

    def log_message(self, format, *args): pass

# ==========================================
# 5. 主线程执行器 (智能上下文解析引擎) - 【防弹重构版】
# ==========================================
def process_api():
    while True:
        try:
            # 【修复 2】：使用无阻塞获取，杜绝死锁隐患
            req = api_queue.get_nowait()
        except queue.Empty:
            break

        req_type = req.get("type", "GET")
        evt = req.get("evt")
        res = req.get("res", {})

        # 【核心修复 3】：无论执行逻辑发生多么诡异的崩溃，都必须确保 finally 中的 evt.set() 执行！
        try:
            if req_type == "GET":
                status_str = "DEFAULT"
                C = bpy.context
                mx, my = global_mouse["x"], global_mouse["y"]
                ui, st, current_area = "UNKNOWN", None, None
                win = C.window if C.window else (C.window_manager.windows[0] if C.window_manager.windows else None)
                
                if win and win.screen:
                    for area in win.screen.areas:
                        if area.x <= mx <= area.x + area.width and area.y <= my <= area.y + area.height:
                            ui = getattr(area, 'ui_type', getattr(area, 'type', 'UNKNOWN'))
                            st = area.spaces.active
                            current_area = area
                            break
                            
                    if ui == "UNKNOWN" and win.screen.areas:
                        workspace_top = max(a.y + a.height for a in win.screen.areas)
                        workspace_bottom = min(a.y for a in win.screen.areas)
                        if my >= workspace_top: ui = "TOPBAR"
                        elif my <= workspace_bottom: ui = "STATUSBAR"

                tags = []
                sc = 0
                is_ortho = False
                obj_type = ""
                append_sc_suffix = False

                if ui == 'VIEW_3D':
                    append_sc_suffix = True
                    if hasattr(st, 'region_3d') and st.region_3d:
                        if st.region_3d.view_perspective == 'ORTHO': is_ortho = True
                    m = C.mode
                    o = C.active_object
                    if o: obj_type = o.type
                    
                    if m == 'EDIT_MESH':
                        tags.append('EDIT')
                        sm = C.tool_settings.mesh_select_mode
                        if o and o.type == 'MESH' and o.data.is_editmode:
                            bm = bmesh.from_edit_mesh(o.data)
                            items = []
                            if sm[0]: tags.append('VERT'); items = bm.verts
                            elif sm[1]: tags.append('EDGE'); items = bm.edges
                            elif sm[2]: tags.append('FACE'); items = bm.faces
                                
                            for item in items:
                                if item.select:
                                    sc += 1
                                    if sc > 1: break
                    else:
                        tags.append(m)
                        if m == 'OBJECT': sc = len(C.selected_objects)
                        else: sc = 1 if o else 0
                            
                elif 'NodeTree' in ui or ui == 'NODE_EDITOR':
                    append_sc_suffix = True
                    tags.append('NODE')
                    tags.append(ui.upper())
                    if getattr(st, 'edit_tree', None):
                        sc = len([n for n in st.edit_tree.nodes if n.select])
                        
                elif ui == 'OUTLINER':
                    append_sc_suffix = True
                    tags.append('OUTLINER')
                    sc = len(getattr(C, 'selected_ids', C.selected_objects))
                    
                elif ui == 'ASSETS':
                    tags.append('ASSETS')
                    append_sc_suffix = False

                elif ui == 'UV':
                    tags.append('IMAGE_EDITOR_UV')
                    append_sc_suffix = False
                    uv_mode = getattr(C.tool_settings, 'uv_select_mode', 'VERTEX')
                    if uv_mode == 'VERTEX': tags.append('VERT')
                    elif uv_mode == 'EDGE': tags.append('EDGE')
                    elif uv_mode == 'FACE': tags.append('FACE')
                    elif uv_mode == 'ISLAND': tags.append('ISLAND')

                elif ui == 'IMAGE_EDITOR':
                    tags.append('IMAGE_EDITOR')
                    append_sc_suffix = False
                    
                elif ui == 'FILE_BROWSER':
                    tags.append('FILE_BROWSER')
                    append_sc_suffix = False
                    
                else:
                    tags.append(ui)
                    append_sc_suffix = False

                if append_sc_suffix:
                    if sc == 0: tags.append('NONE')
                    elif sc > 1: tags.append('MULTI')
                
                if obj_type: tags.append(obj_type)
                if is_ortho: tags.append('ORTHO')

                if tags: status_str = "_".join(tags)
                res["status"] = status_str

            elif req_type == "POST":
                code = req.get("payload", "")
                C = bpy.context
                mx, my = global_mouse["x"], global_mouse["y"]
                win = C.window if C.window else (C.window_manager.windows[0] if C.window_manager.windows else None)
                target_area, target_region = None, None
                
                if win and win.screen:
                    for area in win.screen.areas:
                        if area.x <= mx <= area.x + area.width and area.y <= my <= area.y + area.height:
                            target_area = area
                            target_region = next((r for r in area.regions if r.type == 'WINDOW'), None)
                            break
                
                namespace = globals().copy()
                
                if win and target_area:
                    with C.temp_override(window=win, area=target_area, region=target_region):
                        exec(code, namespace)
                else:
                    exec(code, namespace)

                res["success"] = True
                res["message"] = "代码执行成功"

        except Exception as e:
            # 静默处理异常，保证进程存活
            print(f"Quicker API 逻辑层出现错误: {e}")
            if req_type == "GET": 
                res["status"] = "ERROR_EXCEPTION"
            else:
                res["success"] = False
                res["error"] = str(e)
                
        finally:
            # 无论前面发生什么毁灭性打击，必须执行释放信号锁！
            if evt:
                evt.set()

# ==========================================
# 6. 生命周期管理
# ==========================================
def get_server_config():
    default_ip, default_port = "127.0.0.1", 8765
    try:
        prefs = bpy.context.preferences.addons[__name__].preferences
        addr = prefs.server_address.split(":")
        if len(addr) == 2:
            return addr[0].strip(), int(addr[1].strip())
    except Exception: pass
    return default_ip, default_port

def start_server():
    global http_daemon, http_thread
    if http_daemon is not None: return
    
    ip, port = get_server_config()
    try:
        # 核心替换：使用 ThreadingHTTPServer 防止 Socket 假死
        http_daemon = ThreadingHTTPServer((ip, port), QuickerAPI)
        http_thread = threading.Thread(target=http_daemon.serve_forever, daemon=True)
        http_thread.start()
        print(f">> Quicker 监听服务已启动: {ip}:{port}")
    except Exception as e:
        print(f">> HTTP 服务器启动失败: {e}")

def stop_server():
    global http_daemon, http_thread
    if http_daemon:
        http_daemon.shutdown()
        http_daemon.server_close()
        http_daemon = None
        http_thread = None
        print(">> Quicker 监听服务已关闭")

def queue_processor():
    if not addon_running: return None
    # 【核心修复 4】：给定时器套上防弹外壳，确保它绝对不会被 Blender 彻底注销
    try:
        process_api()
    except Exception as fatal_error:
        print(f"Quicker 致命错误拦截，定时器存活: {fatal_error}")
    return 0.02

def start_services_delayed():
    if not addon_running: return None
    start_server()
    try:
        if bpy.context.window_manager and bpy.context.window_manager.windows:
            win = bpy.context.window_manager.windows[0]
            with bpy.context.temp_override(window=win):
                bpy.ops.wm.mouse_context_spy('INVOKE_DEFAULT')
            return None
    except Exception as e: 
        pass
    return 1.0

def register_keymaps():
    wm = bpy.context.window_manager
    if not wm.keyconfigs.addon: return
    km = wm.keyconfigs.addon.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new("wm.run_clipboard_code", 'V', 'PRESS', ctrl=True, shift=True, alt=True)
    addon_keymaps.append((km, kmi))

def unregister_keymaps():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        for km, kmi in addon_keymaps:
            km.keymap_items.remove(kmi)
    addon_keymaps.clear()

classes = (
    QuickerAddonPreferences,
    WM_OT_RestartQuickerServer,
    WM_OT_RunClipboardCode,
    MouseContextSpy,
)

def register():
    global addon_running
    addon_running = True
    for cls in classes: bpy.utils.register_class(cls)
    register_keymaps()
    bpy.app.timers.register(queue_processor)
    bpy.app.timers.register(start_services_delayed, first_interval=0.5)

def unregister():
    global addon_running
    addon_running = False
    stop_server()
    unregister_keymaps()
    for cls in reversed(classes):
        try: bpy.utils.unregister_class(cls)
        except Exception: pass

if __name__ == "__main__":
    register()